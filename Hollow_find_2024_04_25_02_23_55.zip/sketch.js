let P = [ ]; // dari solve()
let t = []; //dari solve()
let r; //Materi kelas: input user
let k = 300; //Tugas; r dan K input user

//ini juga bisa jadi input
let P0= 20;
let dt=0.1;
let tMax=10;
let grafik; //Chart JS


function setup() {
  createCanvas(400, 500);
  
  r = createInput('0.8'); //input default adalah 0.8
  r.position(20, 40)
  let p = createP('konstanta pertumbuhan') //teks biasa
  p.style('fontsize', '14px');
  p.position(20, 0);
  
  solve();
  r.changed(solve);
  grafik= new Chart(this, config);
  
  
  
  //baris program untuk merespon input user 
  solve(); // untuk inisiasi jalankan terlebih dahulu solve
  r.changed(solve); //jika input berganti, jalankan fungsi solve
}


function draw() {
  background(220);
  
  grafik.update();
}






function solve(){
  
  P[0]=P0;
  t[0]=0;
  let rs = float(r.value());
  let iterNum = int(tMax / dt);
  
  
  for (i=0; i < iterNum; i++){
    P[i+1] = P[i] + dt * P[i] * (1 - P[i]/k)
    t[i+1] = round((i + 1)*dt, 3);
  }
}